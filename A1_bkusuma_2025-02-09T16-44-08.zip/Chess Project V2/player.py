class Player:
    def __init__(self, name, color, captured_pieces):
        self.name = name
        self.color = color
        self.captured_pieces = captured_pieces